#from distutils.log import info
from redescrita import linkedin
import requests
import json
from prueba4 import auth, headers

#from linkedin import linkedin


import string

from oauthlib import *
import oauth2 as oauth
#from linkedin_v2 import linkedin

def user_info(headers):
    '''
    Get user information from Linkedin
    '''
    response = requests.get('https://api.linkedin.com/v2/me', headers = headers)
    requests.get
    user_info = response.json()
    return user_info

 
def open_url(url):
    '''
    Function to Open URL.
    Used to open the authorization link
    '''
    import webbrowser
    print(url)
    webbrowser.open(url)

def get_profile(access_token):
    URL = "https://api.linkedin.com/v2/me"
    headers = {'Content-Type': 'application/x-www-form-urlencoded','Authorization':'Bearer {}'.format(access_token),'X-Restli-Protocol-Version':'2.0.0'}
    response = requests.get(url=URL, headers=headers)
    URL2 ="https://api.linkedin.com/v2/people=" 
    response2 = requests.get(url=URL2, headers=headers)
    print("Buscando personas")
    print(json.dumps(response2.json(), indent=1))

    
def search_people(self,access_token, idPersona):
    URL = "https://api.linkedin.com/v2/people/(id:)?projection=({id},{first},{last)"
    headers = {'Content-Type': 'application/x-www-form-urlencoded','Authorization':'Bearer {}'.format(access_token),'X-Restli-Protocol-Version':'2.0.0'}
    response = requests.get(url=URL, headers=headers)
    open_url('https://api.linkedin.com/v2/people/(id:)')
    #print(json.dumps(response.json(), indent=1))   

if __name__ == '__main__':
    credentials = 'credentials.json'
    access_token = auth(credentials) # Authenticate the API
    headers = headers(access_token) # Make the headers to attach to the API call.
    user_info = user_info(headers) # Get user info
    print(user_info)
    get_profile(access_token)
  
consumer_key = '' #from Linkedin site
consumer_secret = '' #from Linkedin site
consumer = oauth.Consumer(consumer_key, consumer_secret)
authentication = linkedin.LinkedInAuthentication(consumer_key, consumer_secret, 'http://localhost:8888', linkedin.PERMISSIONS.enums.values())
